import cv2 as cv
import numpy as np
import seaborn as sns
from sklearn.svm import SVC
from matplotlib import pyplot as plt
from sklearn.decomposition import PCA
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.model_selection import train_test_split

pretrained = cv.CascadeClassifier('haarcascade_frontalface_default.xml')

# CAPTURE MASK DATA
capture = cv.VideoCapture(0)
data = []
while True:
    ret, img = capture.read()
    if ret:
        faces = pretrained.detectMultiScale(img)
        for x, y, w, h in faces:
            cv.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 4)
            face = img[y:y + h, x:x + w, :]
            face = cv.resize(face, (50, 50))
            if len(data) < 400:
                data.append(face)
        cv.imshow('Window', img)
        if cv.waitKey(2) == 27 or len(data) >= 200:
            break
capture.release()
cv.destroyAllWindows()

np.save('mask.npy', data)

plt.figure(figsize=(2, 2))
plt.imshow(data[0])
plt.show()

# CAPTURE NO MASK DATA
capture = cv.VideoCapture(0)
data = []
while True:
    ret, img = capture.read()
    if ret:
        faces = pretrained.detectMultiScale(img)
        for x, y, w, h in faces:
            cv.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 4)
            face = img[y:y + h, x:x + w, :]
            face = cv.resize(face, (50, 50))
            if len(data) < 400:
                data.append(face)
        cv.imshow('Window', img)
        if cv.waitKey(2) == 27 or len(data) >= 200:
            break
capture.release()
cv.destroyAllWindows()

np.save('no_mask.npy', data)

plt.figure(figsize=(2, 2))
plt.imshow(data[1])
plt.axis(False)
plt.show()

mask = np.load('mask.npy')
no_mask = np.load('no_mask.npy')

print(mask.shape)
print(no_mask.shape)

X = np.r_[no_mask, mask]
X = X.reshape(X.shape[0], -1)
Y = np.zeros(X.shape[0])
Y[no_mask.shape[0]:] = 1.0

X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20)
print(len(X_train), len(X_test), len(Y_train), len(Y_test))

pca = PCA(n_components=3)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)

model = SVC()
model.fit(X_train, Y_train)
print(f"Model score: {model.score(X_test, Y_test)}")

Y_pred = model.predict(X_test)
print("Accuracy Score:", accuracy_score(Y_test, Y_pred))
print("Classification Report:\n", classification_report(Y_test, Y_pred))

cm = confusion_matrix(Y_test, Y_pred)
plt.figure(figsize=(4, 3))
g = sns.heatmap(cm, cmap='Blues', annot=True, fmt='g')
g.set_xticklabels(labels=['No Mask (0)', 'Mask (1)'], rotation=30)
g.set_yticklabels(labels=['No Mask (0)', 'Mask (1)'], rotation=0)
plt.ylabel('True Label', fontsize=14)
plt.title('Confusion Matrix', fontsize=16)
plt.show()

capture = cv.VideoCapture(0)
names = {0: 'No Mask', 1: 'Mask'}
font = cv.FONT_HERSHEY_COMPLEX
while True:
    ret, img = capture.read()
    if ret:
        faces = pretrained.detectMultiScale(img)
        for x, y, w, h in faces:
            cv.rectangle(img, (x, y), (x + w, y + h), (255, 0, 255), 4)
            face = img[y:y + h, x:x + w, :]
            face = cv.resize(face, (50, 50))
            face = face.reshape(1, -1)
            face = pca.transform(face)
            pred = model.predict(face)
            n = names[int(pred)]
            cv.putText(img, n, (x, y), font, 1, (244, 250, 250), 2)
        cv.imshow('Window', img)
        if cv.waitKey(2) == 27:
            break
capture.release()
cv.destroyAllWindows()
